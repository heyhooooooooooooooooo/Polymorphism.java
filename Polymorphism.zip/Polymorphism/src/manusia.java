/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author USER
 */
public class manusia {
    //deklarasi variable
    private double TinggiBadan;
    
            //constructur
    public manusia (double TB)
    {
        TinggiBadan = TB;
    }
            //getter
    public double getTB()
    {
        return TinggiBadan;
    }
            //method HtgBBI
    public double HtgBBI()
    {
        return 0.0;
    }
}
