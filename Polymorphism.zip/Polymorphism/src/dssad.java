/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author USER
 */
public class dssad {
    static double maxNumber (double a, double b){
        if (a<b) {
            return a;
        }else{
            return b;
        }
    }
    public static void main (String[] argrs){
        System.out.println(maxNumber(7.5, 8.3));
        System.out.println(maxNumber(20, 42));
        
    }
}
