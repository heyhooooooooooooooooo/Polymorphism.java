/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mine;

/**
 *
 * @author USER
 */
public class Overloading {
    public static void main (String[]args){
        
        Calculate cal= new Calculate();
        
        System.out.println("Sum(4,3)="+cal.sum(4, 3));
        System.out.println("Sum(3,2,1="+cal.sum(3,2,1));
        
    }
   
}

class Calculate{
    public int sum (int a,int b){
        return a+b;
    }
    public int sum (int a, int b, int c){
        return a+b+c;
    }
}