/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mine;

/**
 *
 * @author USER
 */
class Bird{
    public void sing(){
        System.out.println("twet twet twet");
    }
    
}
class Robin extends Bird{
    
    }
class Pelican extends Bird{
    
}

public class NewClass {
    public static void main (String[]args) {
        Pelican b = new Pelican ();
        b.sing();
        
        
    }
    
}
