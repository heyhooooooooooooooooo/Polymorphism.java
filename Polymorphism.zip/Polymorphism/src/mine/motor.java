/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mine;

/**
 *
 * @author USER
 */
public class motor extends kendaraan {
    public int maxspeed;
    
    public void tancapgas(){
      System.out.println("kendaraan berjalan dengan" +jumlahroda+"roda");
    }
        
    }
    
    
  

