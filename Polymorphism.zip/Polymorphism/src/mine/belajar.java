/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mine;

/**
 *
 * @author USER
 */
public class belajar {
    public static void main (String[]args){
        
        kendaraan mobil= new kendaraan();
        mobil.jumlahroda= 4;
        mobil.tancapGas();
        
        motor honda = new motor();
        honda.jumlahroda=2;
        honda.tancapgas();
        
    }
    
}
