/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mine;

/**
 *
 * @author USER
 */
public class benda {
    public  void NamaBarang (String nama){
        System.out.println(" Method NamaBarang  ");
        
    }
    public void NamaBarang (String nama, int ukuran){
        System.out.println("Method ukuran barang");
        
    }
    
    public void NamaBarang (String nama, int ukuran, String pemilik){
        
    }
            
    
}
