/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mine;

/**
 *
 * @author USER
 */
public class kendaraan {
    
    public int harga;
    private String nama;
    protected int jumlahroda;
    
    public void tancapgas(){
        System.out.println("kendaraan berjalan dengan" +jumlahroda+"roda");
    }
    
}
