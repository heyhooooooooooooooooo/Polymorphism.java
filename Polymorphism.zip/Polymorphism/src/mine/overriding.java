/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mine;
class collage{
    public void move(){
        System.out.println("Collage is open");
    }
    
}
class univ extends collage{
    public void move(){
        System.out.println("University is open too");
        
    }
    
}
/**
 *
 * @author USER
 */
public class overriding {
    public static void main (String args []){
        collage a= new collage();
        collage b= new univ ();
        
        a.move();
        b.move();
    }
    
}
